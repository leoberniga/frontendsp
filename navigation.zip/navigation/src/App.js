import React from 'react';
import logo from './logo.svg';
import Header from './components/header';
import Footer from './components/footer';
import { Switch, Route } from 'react-router-dom';
import Screen1 from './components/screens/screen1';
import Screen2 from './components/screens/screen2';
import Screen3 from './components/screens/screen3';
import Home from './components/screens/home';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div>
        <Header />
        <Switch>
          <Route path="/screen1">
            <Screen1 />
          </Route>
          <Route path="/screen2">
            <Screen2 />
          </Route>
          <Route path="/screen3">
            <Screen3 />
          </Route>
          <Route path="/">
            <Home />
          </Route>
        </Switch>
        <Footer />
      </div>
    );
  }
}

export default App;
