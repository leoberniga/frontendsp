import React from 'react';

class Footer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div style={{ backgroundColor: 'black', textAlign: 'center', padding: 10, color: 'gray', marginTop: 50 }}>
        Soy un footer
      </div>
    );
  }
}

export default Footer;