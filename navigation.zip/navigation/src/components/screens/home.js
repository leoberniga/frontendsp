import React from 'react';
import Logo from '../../logo.svg';

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div>
        <h1>Hola Home</h1>
        <img src={Logo} />
      </div>
    );
  }
}

export default Home;