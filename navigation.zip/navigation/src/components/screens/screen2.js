import React from 'react';

class Screen2 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <h1>Hola Screen2</h1>
    );
  }
}

export default Screen2;