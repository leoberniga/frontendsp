import React from 'react';

class Screen1 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-12 col-md-6">
            <h3>Columna 1</h3>
            <p>Sint incididunt do labore consectetur id in irure pariatur id. Minim enim aliqua ipsum magna cillum et nulla aute est culpa aute quis id enim. In aute ullamco in anim cupidatat nostrud magna sint dolore sit. Magna labore dolore ut pariatur ex voluptate laborum nostrud magna enim et in duis. Nostrud pariatur labore occaecat occaecat do.</p>
          </div>
          <div className="col-12 col-md-6">
            <img src="http://placehold.it/300" />
          </div>
        </div>
      </div>
    );
  }
}

export default Screen1;